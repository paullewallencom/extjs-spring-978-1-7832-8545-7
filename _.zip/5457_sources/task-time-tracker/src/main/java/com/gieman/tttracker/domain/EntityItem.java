package com.gieman.tttracker.domain;

public interface EntityItem<T> {
    
    public T getId();
    
}
