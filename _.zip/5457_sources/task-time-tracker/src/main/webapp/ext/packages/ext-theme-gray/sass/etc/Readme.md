# ext-theme-gray/sass/etc

This folder contains miscellaneous SASS files. Unlike `"ext-theme-gray/sass/etc"`, these files
need to be used explicitly.
